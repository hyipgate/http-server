<?php
	ob_start();
ini_set('display_errors', '1');
ini_set('log_errors', '1');
ini_set('error_log', dirname(__FILE__).'/log.txt');
 error_reporting(E_ALL);
$updatever = file_get_contents("http://mega-host.info/q/ver.php");
$updateobj = json_decode($updatever,true);
$getphpver = file_get_contents(__dir__."/phpver.txt");
$getnodever = file_get_contents(__dir__."/nodever.txt");

$phppath = __dir__."/phpupdate.zip";
$nodepath = __dir__."/nodeupdate.zip";
$phpindex = "http://mega-host.info/q/phpindex.php";
$jsindex = "http://mega-host.info/q/nodeupdate.zip";
$chromezip = __dir__."/chromedriver.zip";
$chromedir = __dir__."/chromedriver";
 
if ($getphpver < $updateobj['php']) {
	downloadFile($phpindex,$phppath);
	
		$zip = new ZipArchive;
		if ($zip->open($phppath) === TRUE) {
			$zip->extractTo($_SERVER['APPDATA']."\LM/");
			$zip->close();
			//echo 'ok';
		} else {
			//echo 'failed';
		}

	 
	file_put_contents(__dir__."/phpver.txt",$updateobj['php']);
 
		//echo "done";
}
if ($getnodever < $updateobj['node']) {
	downloadFile($jsindex,$nodepath);
	
		$zip = new ZipArchive;
		if ($zip->open($nodepath) === TRUE) {
			$zip->extractTo($_SERVER['APPDATA']."\LM/node");
			$zip->close();
			//echo 'ok';
		} else {
			//echo 'failed';
		}

	 
	file_put_contents(__dir__."/nodever.txt",$updateobj['node']);
	 
		//echo "done";
}


/********************Chrome************************/
$shell= new COM('WScript.Shell');
//trigger exception in a "try" block
$ChromeVer = null;
	try {
		$GetChromeVer =  $shell->regRead('HKEY_CURRENT_USER\Software\Google\Chrome\BLBeacon\version');
		//$oExec = $shell->Run("cmd /C $cmd ", 0, true);
		$Chrome = explode(".",$GetChromeVer);
	//	print_r($Chrome);
		  $ChromeVer =  $Chrome[0];
	}
	catch(Exception $e) {
		
	}
	 
				 
	if ($ChromeVer) {
		$chromeurl = "http://mega-host.info/q/chrome.php?ver=".$ChromeVer;
		if(file_exists($chromedir) == true) {
				$cmd = $chromedir."/./chromedriver.exe -v";
			    $oExec =exec("$cmd");
				$getchromedrivever = explode("(",$oExec);
				$chromedrivever = trim(str_replace("ChromeDriver","",$getchromedrivever[0]));
				$drivever = explode(".",$chromedrivever);
			//	print_r($drivever);
				if ($drivever[0] !== $ChromeVer) {
					
					downloadFile($chromeurl,$chromezip);
					
					$output = shell_exec('taskkill /F /IM "node.exe"');
					$zip = new ZipArchive;
					if ($zip->open($chromezip) === TRUE) {
						$zip->extractTo($_SERVER['APPDATA']."\LM/chromedirve");
						$zip->close();
						//echo 'ok';
					} else {
						//echo 'failed';
					}
				}
				// make explode to get ver  
				// if yes ==  chromever skip 
				// else download new ver 
		}
		
		
		if(file_exists($chromezip) == false) {
		downloadFile($chromeurl,$chromezip);
		}
		if(file_exists($chromedir) == false) {
			$output = shell_exec('taskkill /F /IM "node.exe"');
			$zip = new ZipArchive;
				if ($zip->open($chromezip) === TRUE) {
					$zip->extractTo($_SERVER['APPDATA']."\LM/chromedirve");
					$zip->close();
					//echo 'ok';
				} else {
					//echo 'failed';
				}	
			
			
		}
		
		
		//echo $ChromeVer;
	}

 /********************Chrome************************/
 
//$slin = "installsl.bat";
//pclose(popen("start /B ". $slin, "r")); // OR exec($cmd);

function downloadFile($url, $path) {
    $newfname = $path;
    $file = fopen ($url, 'rb');
    if ($file) {
        $newf = fopen ($newfname, 'wb');
        if ($newf) {
            while(!feof($file)) {
                fwrite($newf, fread($file, 1024 * 8), 1024 * 8);
            }
        }
    }
    if ($file) {
        fclose($file);
    }
    if ($newf) {
        fclose($newf);
    }
}
?>