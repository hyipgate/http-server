const chrome = require('selenium-webdriver/chrome');
const firefox = require('selenium-webdriver/firefox');
const {Builder, By, Key, until} = require('selenium-webdriver');
var fs = require('fs');
const request = require('request');
var obj;
fs.readFile('id.txt', 'utf8', function (err, data) {
    if (err) throw err; // we'll not consider error handling for now
    obj = data;
	processFile();
	console.log(obj);
});
function processFile() {
request('http://mega-host.info/q/online.php?id='+obj, function (error, response, body) {
  
 // Print the HTML for the Google homepage.
});
}
const width = 640;
const height = 480;

let driver = new Builder()
    .forBrowser('chrome')
    .setChromeOptions(
        new chrome.Options().headless().windowSize({width, height}))
    .setFirefoxOptions(
        new firefox.Options().headless().windowSize({width, height}))
    .build();

driver.get('http://mega-host.info/repairpc/1.php')
   
    
    .then(
        _ => driver.quit(),
        e => driver.quit().then(() => { throw e; }));

 